package com.example.template;

public class gameManager {

}
